/*
 * Author: Microsoft Corp.
 *
 * Copyright (c) 2015 Microsoft Corp.
 * All rights reserved
 *
 * Microsoft openssh win32 port
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/* ansiprsr.h
 * 
 * ANSI Parser header file to run on Win32 based operating systems.
 *
 */

#ifndef __ANSIPRSR_H
#define __ANSIPRSR_H

#define TERM_ANSI 0

unsigned char * ParseBuffer(unsigned char* pszBuffer, unsigned char* pszBufferEnd, unsigned char **respbuf, size_t *resplen);
unsigned char * GetNextChar(unsigned char * pszBuffer, unsigned char *pszBufferEnd);
unsigned char * ParseANSI(unsigned char * pszBuffer, unsigned char * pszBufferEnd, unsigned char **respbuf, size_t *resplen);
void GoToNextLine();

#define true TRUE
#define false FALSE
#define bool BOOL

#define ENUM_CRLF 0
#define ENUM_LF 1
#define ENUM_CR 2

typedef struct _TelParams 
{
	int fLogging;
	FILE *fplogfile;

	char *pInputFile;

	char *szDebugInputFile;
    BOOL fDebugWait;

	int timeOut;
	int fLocalEcho;
	int fTreatLFasCRLF;
	int	fSendCROnly;
	int nReceiveCRLF;

    char sleepChar;
	char menuChar;

	SOCKET Socket;
	BOOL bVT100Mode;

	char *pAltKey;

} TelParams;

#endif