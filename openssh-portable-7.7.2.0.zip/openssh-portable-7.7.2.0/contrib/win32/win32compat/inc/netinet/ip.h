#ifndef COMPAT_IP_H
#define COMPAT_IP_H 1

/* Compatibility header to avoid lots of #ifdef _WIN32's in includes.h */

#endif
