#include "crtheaders.h"
#include STDLIB_H

#define environ _environ
void freezero(void *, size_t);